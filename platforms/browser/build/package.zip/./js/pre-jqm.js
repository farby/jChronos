$(document).bind('mobileinit',function(){
        $.mobile.pushStateEnabled = false;
});
